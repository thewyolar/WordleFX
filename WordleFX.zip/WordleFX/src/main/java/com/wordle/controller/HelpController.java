package com.wordle.controller;

import javafx.fxml.FXML;
import javafx.scene.image.ImageView;

public class HelpController {
    @FXML
    private ImageView gameButton;

    public ImageView getGameButton() { return gameButton; }
}
