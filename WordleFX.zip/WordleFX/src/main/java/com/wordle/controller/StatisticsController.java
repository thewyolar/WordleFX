package com.wordle.controller;

public class StatisticsController {
}
